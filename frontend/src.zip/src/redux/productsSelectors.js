export const selectDate = state => state.products.date

export const getProducts = state => state.products.productsList