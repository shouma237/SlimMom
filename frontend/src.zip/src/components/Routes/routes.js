export const routes = {
  home: '/home',
  diary: '/diary',
  calculator: '/calculator',
  login: '/login',
  register: '/register',
};
